---
marp: true
theme: cc-dark
paginate: true
size: 16:9
---

<!--
Lezione 1 — Fondamenta ISO 27001 applicate a reti e cloud
Data: 22/07/2026, 9:00-12:00 (3h)
Fonte: docs/prds/PRD_Corso_Sicurezza_Reti_Cloud.md — sezione 2

Questo deck copre: Apertura, Fondamenta ISO 27001, Attività pratica (risk assessment).
Si ferma volutamente PRIMA del laboratorio Floci: quel blocco (scenario vulnerabile,
istruzioni CLI, hint) va preparato a parte quando arriviamo a quel punto del corso.

Timing indicativo (totale 180 min, di cui 30 fissati nel PRD per l'apertura):
- Apertura: 30 min (fisso da PRD)
- Fondamenta ISO 27001: ~45-50 min
- Attività pratica (risk assessment): ~30-35 min
- Laboratorio Floci: ~60-70 min (da preparare a parte)
-->

# Tecnico per la sicurezza delle reti e dei servizi in cloud

## Lezione 1 — Fondamenta ISO 27001 applicate a reti e cloud

22/07/2026 — 9:00-12:00

---

# Chi sono

---

- Matteo Buferli 
- Laurea Triennale in Scienze dell'Informazione a Bologna
- Founder di Comuni-Chiamo.com

---

- Ho cominciato ad usare il pc a 13 anni (ne compio 40 a breve), con un bellissimo Pentium II della Packard Bell, che ho rotto dopo pochi mesi di utilizzo ...

---

![bg cover](images/pb.jpg)

---

- Skateboard + walkman + fotocamera usa e getta

---

![bg cover](images/walkman.webp)

---

- a 17 anni formo la Gilda italiana più grande su World of Warcraft: era la cosa piu' vicina ai social network che c'era all'epoca
- parlavamo su un software che si chiama TeamSpeak

---

![bg cover](images/wow.jpg)

---

![bg cover](images/ts.jpg)

---

- 2009: mi laurea in scienze dell'informazione a bologna, lavoro quasi 2 anni per Almalaurea
- 2011: fondo **Comuni-Chiamo** — software per la gestione delle segnalazioni dei cittadini, oggi usato da 100+ comuni e 6.500+ operatori
- dal 2016 al 2023: Mentor @ Fondazione Golinelli --- Palestra di imprenditorialità

---

## Due storie da raccontare a voce

- 🎙️ **[racconta: aneddoto AI]** — un episodio concreto lavorando con l'AI, cosa ha sorpreso o cosa è andato storto
- 🎙️ **[racconta: aneddoto ISO 27001]** — un episodio dal percorso di certificazione di Comuni-Chiamo

<!-- notes: aneddoti volutamente non pre-scritti — si raccontano a voce, poi si analizzano insieme ai ragazzi dopo averli raccontati. -->

---

## Sharing is caring!

Giro di presentazioni (volontario):

- Nome
- Cosa ti ha portato a questo percorso
- Cosa ti aspetti da queste 9 ore

---

## Come funzionano queste 9 ore

| Data | Orario | Argomento |
|---|---|---|
| 22/07 | 9:00-12:00 | Fondamenta ISO 27001 + lab Floci |
| 27/07 | 9:00-12:00 | L'AI nella sicurezza operativa |
| 29/07 | 9:00-12:00 | Convergenza e messa in pratica |

- Aspettative reciproche: partecipazione attiva, domande benvenute in ogni momento
- Modalità: teoria breve → esempi reali → attività pratica/lab

---

# Fondamenta ISO 27001 applicate a reti e cloud

---

## Cos'è un ISMS (?)

---

Non è:

- un prodotto
- un firewall
- una soluzione

---

**Information Security Management System**

È un **sistema di gestione**

- Un insieme di politiche, processi e controlli
- Per gestire il rischio sulle informazioni in modo continuo
- Non "sicurezza fatta una volta", ma un ciclo che si ripete

---

## Il ciclo PDCA

**Plan → Do → Check → Act**

| Fase | Cosa significa | Esempio pratico |
|---|---|---|
| **Plan** | Identifico rischi, definisco policy | Rilevo che i backup non sono testati |
| **Do** | Applico i controlli | Introduco test di restore mensili |
| **Check** | Verifico che funzioni | Audit interno sui backup |
| **Act** | Correggo e migliora | Aggiorno la policy di backup |

Il ciclo non finisce mai: si ripete e migliora nel tempo.

---

## Estemporaneo vs strutturato

**Fare sicurezza "a spot"**
- Reagisco quando succede qualcosa
- Nessuna tracciabilità delle decisioni
- Dipende dalla persona, non dal processo

**Gestire la sicurezza con un sistema**
- Rischi identificati e rivalutati nel tempo
- Decisioni documentate e ripetibili
- Sopravvive al turnover delle persone

---

## Perché le aziende adottano ISO 27001

Non è solo compliance normativa:

- **Gestione concreta del rischio** — sapere cosa può andare storto prima che succeda
- **Credibilità verso clienti e partner** — spesso è un requisito contrattuale
- **Linguaggio comune** — audit, fornitori e clienti parlano lo stesso framework

---

## I controlli Annex A rilevanti per reti e cloud

Quattro aree su cui ci concentriamo oggi:

1. Gestione della sicurezza di rete
2. Controllo accessi
3. Crittografia
4. Sicurezza dei servizi cloud (5.23)

---

## 1. Gestione della sicurezza di rete

- **Segmentazione** — non tutto deve parlare con tutto
- **Monitoraggio** — sapere cosa attraversa la rete
- **Controllo del traffico** — regole esplicite, non "permetti tutto per comodità"

---

## 2. Controllo accessi

- **Autenticazione** — sei davvero chi dici di essere?
- **Autorizzazione** — hai il diritto di fare questa cosa specifica?
- **Minimo privilegio** — solo i permessi strettamente necessari al ruolo

<!-- notes: collegamento diretto al laboratorio Floci che faremo più avanti oggi. -->

---

## 3. Crittografia

- **Dati a riposo** (at rest) — cosa succede se rubano il disco?
- **Dati in transito** (in transit) — cosa succede se qualcuno intercetta il traffico?
- Non è "attivare un flag": è capire cosa si sta proteggendo e da chi

---

## 4. Sicurezza dei servizi cloud (controllo 5.23)

- **Responsabilità condivisa**: cosa fa il provider, cosa fai tu
- Il provider protegge *il* cloud, tu proteggi *ciò che ci metti dentro*
- Cosa verificare in un contratto cloud: SLA, localizzazione dati, notifica incidenti

---

## Un caso reale

🎙️ **[racconta: episodio da un audit o un'implementazione ISO 27001/9001 seguita in prima persona]**

- Cosa è andato storto (o bene)
- Perché
- Il "dietro le quinte" che non si trova su un manuale

<!-- notes: aneddoto volutamente non pre-scritto — si racconta a voce, poi si analizza insieme ai ragazzi. È il valore aggiunto rispetto a un corso standard. -->

---

# Attività pratica

---

## Scenario guidato: migrazione su cloud

Un'azienda deve spostare un servizio interno su cloud (AWS/Azure).

In piccoli gruppi:

1. Identificate gli **asset** coinvolti (dati, sistemi, credenziali)
2. Identificate le **minacce** plausibili
3. Identificate le **vulnerabilità** dello scenario

<!-- notes: dividere in gruppi da 3-4 persone, 15-20 min di lavoro. -->

---

## Discussione in plenaria

- Ogni gruppo condivide 1-2 rischi individuati
- Confronto: cosa è emerso in comune? Cosa è emerso di diverso?
- Collegamento ai controlli Annex A visti prima — a quale controllo risponde ogni rischio?

<!-- notes: 10-15 min. -->

---

## Ora mettiamo le mani in pasto

Passiamo dal laboratorio "sulla carta" a un ambiente cloud vero (anche se locale e finto):

**Laboratorio tecnico — Floci**

<!-- STOP: contenuto del laboratorio Floci da preparare a parte quando si arriva a questo punto.
Vedi docs/prds/PRD_Corso_Sicurezza_Reti_Cloud.md sezione "Laboratorio tecnico — Floci". -->
